﻿function FormatNumber(srcStr,nAfterDot){
	var srcStr,nAfterDot;
	srcStr = ""+srcStr+"";
	strLen = srcStr.length;			//原长度
	dotPos = srcStr.indexOf(".",0);		//切分点
	if (dotPos==-1){
		resultStr = srcStr+".";
		for (i=0;i<nAfterDot;i++){
			var resultStr = resultStr+"0";
		}
　　　　	return resultStr;
	}else{
		var tmpChar=srcStr.split(".");
		var AFDOTChar=tmpChar[1];
		if(AFDOTChar=="")AFDOTChar="0";
		var AFDOTlen=AFDOTChar.length;
		var AFDOTlen=parseInt(AFDOTlen);
		var nAfterDot=parseInt(nAfterDot);


		if(AFDOTlen==nAfterDot){
			var resultStr=tmpChar[0]+"."+AFDOTChar;
			return resultStr;
		}

		if(AFDOTlen<nAfterDot){
			for(var i=0;i<(nAfterDot-AFDOTlen);i++){
				AFDOTChar=AFDOTChar+"0";
			}
			var resultStr=String(tmpChar[0])+"."+String(AFDOTChar);
			return resultStr;
		}
				
		if(AFDOTlen>nAfterDot){
			AFDOTChar=AFDOTChar.substring(0,nAfterDot);
			var resultStr=String(tmpChar[0])+"."+String(AFDOTChar);
			return resultStr;
		}
	}
}