#!/bin/sh

if [ -f "/sbin/service" ]; then
    /sbin/service fikkerd start
else
    /usr/sbin/service fikkerd start
fi
